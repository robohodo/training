﻿<#
 JAVA UNINSTALLER
#>

#=============================================================
Clear-Host
$ErrorActionPreference = "continue"
$pcnamelocal = Get-Childitem env:computername
$pcname = $pcnamelocal.value
$LogToFileName = "c:\heb\audits\Java.log"
$array = @()
$obj = $null
$unstrings = @()
#=============================================================

$VersionsToKeep = @('none')
#$VersionsToKeep = @('8.0.920.14','2.8.91.15')
	
#=============================================================

Function Logit([string]$Message){
(Get-Date).ToShortTimeString() + " - [" + $Message + " ]:: " | Out-File $LogToFileName -Append 
} 
Logit($pcname) 

Function KillProcess($process){

if((get-process "$process" -ErrorAction SilentlyContinue) -eq $Null){ 
 Logit ("$process Not Running")
}
else{ 
    Logit ("Killing $process")
    $status = Stop-Process -processname $process -Force -PassThru
    Logit ("Killed Process: " + $status)
 }
} 

    
Function UninstallApp($lookfor, $switches)
{ 
    $array = @()
    $RegToDelete = @()
    Logit("Looking for "+$lookfor) 
    $UninstallKeys=@("SOFTWARE\\Wow6432Node\\Microsoft\\Windows\\CurrentVersion\\Uninstall", "SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Uninstall" )
    foreach($UninstallKey in $UninstallKeys)
	{
        Logit("Checking Registry - " + $UninstallKey)
   	    $reg=[microsoft.win32.registrykey]::OpenRemoteBaseKey('LocalMachine',$pc) 
	    $regkey=$reg.OpenSubKey($UninstallKey) 
	    $subkeys=$regkey.GetSubKeyNames() 
    
            foreach($key in $subkeys)
		        {
                    $thisKey=$UninstallKey+"\\"+$key
                    $thisSubKey=$reg.OpenSubKey($thisKey)
                    $Displayname = $thisSubKey.GetValue("DisplayName")
                    $DisplayPublisher = $thisSubKey.GetValue("Publisher")
       
                            #If($Displayname -like "*$lookfor*")
                            If(($Displayname -like '*Java*') -and 
                             ($Displayname -notlike '*Devel*') -and
                             ($Displayname -notlike '*SDK*') -and
                             ($Displayname -notlike '*JDK*') -and
                             ($Displayname -notlike '*Auto Updater*') -and
                             (($DisplayPublisher -like '*Oracle*') -or
                             ($DisplayPublisher -like '*Sun Microsystems*')) -and 
                             ($Displayname -ne $VersionsToKeep))

                            {   
                                $RegToDelete += $thisKey
                                Logit("Found - " + $Displayname)
                                $obj = New-Object PSObject
		                        $obj | Add-Member -MemberType NoteProperty -Name "ComputerName" -Value $pcname
		                        $obj | Add-Member -MemberType NoteProperty -Name "DisplayName" -Value $($thisSubKey.GetValue("DisplayName"))
		                        $obj | Add-Member -MemberType NoteProperty -Name "DisplayVersion" -Value $($thisSubKey.GetValue("DisplayVersion"))
                                $obj | Add-Member -MemberType NoteProperty -Name "UninstallString" -Value $($thisSubKey.GetValue("UninstallString"))
		                        $array += $obj
                            }
                }
      }

 # Getting Uninstall Strings

 Logit("Getting Uninstall Strings") 
 $unstrings = @()     
 $array = $array | Where-Object { $_.DisplayName } | Sort-Object DisplayName
        ForEach ($item in $array)
        {write-host  $($item.Displayname) -ForegroundColor Yellow
            LOGIT "$($item.Computername)|$($item.DisplayName)|$($item.DisplayVersion)|$($item.UninstallString)" 
            $unstringbase = $item.UninstallString
            $unstring = "$unstringbase $switches"
            $unstrings += $unstring
        }


# Uninstalling Applications
 Logit("Begin Uninstall") 

        ForEach ($string in $unstrings)
        {
        $stringX = $string.Replace('/I','/X')
        write-host $stringX -ForegroundColor Cyan
        Logit("Executing " + $string)
        $Removal = (Start-Process cmd -ArgumentList "/c $stringX"  -WindowStyle Hidden -wait -Passthru).exitcode
        Logit ("Uninstall completed with ErrorCode: " + $Removal)
        Logit("Execution Completed")
        }
 Logit("Done Uninstalling " + $lookfor)

 # Removing Uninstall Registry Keys
    
    Logit("Removing Registry keys in CurrentVersion") 
    Foreach($KeyToDelete in $RegToDelete){
    $KeyToDelete = $KeyToDelete.Replace('SOFTWARE\\','HKLM:\SOFTWARE\')
    $KeyToDelete = $KeyToDelete.Replace('\\','\')
    If(Test-Path $KeyToDelete){Remove-Item $KeyToDelete -Force -Recurse
    LOGIT("$KeyToDelete deleted")}
    Else{LOGIT("$KeyToDelete Not Found")}
}
 } 


#=============================================================
# KILLING PROCESSES:
#=============================================================

If($pcname -like "CUST*"){
KillProcess("java*")
KillProcess("plink*")
KillProcess("ROBOT*")
KillProcess("LAUNCH2*")}

KillProcess("Java*")
KillProcess("iexplorer")
KillProcess("iexplore")
KillProcess("firefox")
KillProcess("chrome")
KillProcess("jusched")
KillProcess("jp2launcher")
KillProcess("jqsw")
KillProcess("java")


#=============================================================
# UNINSTALL BEGINS:
#=============================================================

 UninstallApp "Java" "/qn REBOOT=ReallySuppress REMOVE=ALL"
 
#=============================================================
#Delete Folders
#=============================================================

KillProcess("Java*")
KillProcess("iexplorer")
KillProcess("iexplore")
KillProcess("firefox")
KillProcess("chrome")
KillProcess("jusched")
KillProcess("jp2launcher")
KillProcess("jqsw")
KillProcess("java")

LOGIT("Deleting Folders")

$OldjavaFileName = "C:\Program Files\JavaSoft"
if(Test-Path -path $OldjavaFileName) {
Remove-Item $OldjavaFileName -Force -Recurse
LOGIT ( "C:\Program Files\JavaSoft removed")}
Else {LOGIT( "C:\Program Files\JavaSoft Does not exist")}

$OldjavaFileName2 = "C:\Program Files\Java"
if(Test-Path -path $OldjavaFileName2) {
Remove-Item $OldjavaFileName2 -Force -Recurse
LOGIT( "C:\Program Files\Java removed")}
Else {LOGIT( "C:\Program Files\Java Does not exist")}

$OldjavaFileName3 = "C:\Program Files (x86)\Java"
if(Test-Path -path $OldjavaFileName3) {
Remove-Item $OldjavaFileName3 -Force -Recurse
LOGIT( "C:\Program Files (x86)\Java removed")}
Else {LOGIT( "C:\Program Files (x86)\Java Does not exist")} 


$OldjavaFileName4 = "C:\ProgramData\Oracle\Java"
if(Test-Path -path $OldjavaFileName4) {
Remove-Item $OldjavaFileName4 -Force -Recurse
LOGIT( "C:\ProgramData\Oracle\Java removed")}
Else {LOGIT( "C:\ProgramData\Oracle\Java Does not exist")} 


Get-ChildItem -Path "C:\Users\*\AppData\LocalLow\Sun\Java" | Foreach-Object {Remove-Item $_ -Force -Recurse}
LOGIT( "Appdata\LocalLow\Sun\Java Removed")


LOGIT("Cleaning up Registry Entries")
$regkeypath = @('HKLM:\SOFTWARE\wow6432node\JavaSoft',
'HKLM:\SOFTWARE\JavaSoft','HKCU:\Software\JavaSoft')
Foreach($regkeypath1 in $regkeypath){
If(Test-Path $regkeypath1){Remove-Item $regkeypath1 -Force -Recurse
LOGIT("$regkeypath1 deleted")}
Else{LOGIT("$regkeypath1 Not Found")}
}
LOGIT("Regsitry cleanup completed")
LOGIT("Java cleanup completed. Rebooting..")




#=============================================================
#   COMPLETE
#=============================================================
