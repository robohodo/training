﻿<#
  Java Install 
 
  - Installs Latest msi specified in script
  
  Created:     12.06.2016
  Version:     1.2
  Author:      Edwin Paul

#>

#=============================================================
Clear-Host
$ErrorActionPreference = "silentlycontinue"
$pcnamelocal = Get-Childitem env:computername
$pcname = $pcnamelocal.value
$LogToFileName = "c:\heb\audits\Java.log"
#=============================================================
$ProductName = "Java"
$ProductVersion = "8 Update 102"
$MsiFileJava = "c:\heb\install\Javav8update102\jre-8u102.msi"
$ArgumentsJava = "/i " + $MsiFileJava + " /qn INSTALLCFG=c:\heb\install\Javav8update102\javajava.settings.cfg /L*Vx c:\heb\audits\JavaMsiLog.log" 

#=============================================================
Function Logit([string]$Message){
(Get-Date -Format G) + " - [" + $Message + " ]:: " | Out-File $LogToFileName -Append 
}
Function KillProcess($process){

if((get-process "$process" -ErrorAction SilentlyContinue) -eq $Null){ 
 Logit ("$process Not Running")
}
else{ 
    Logit ("Killing $process")
    $status = Stop-Process -processname $process -Force -PassThru
    Logit ("Killed Process: " + $status)
 }
}


Logit("Starting Upgrade - " + $ProductName + " - " + $ProductVersion)

Logit("Killing Java")
KillProcess("java*")


#Install Java

	Logit ("Starting the Java Install")
	$installjava = (start-process -Filepath msiexec.exe $ArgumentsJava -wait -Passthru).exitcode
	Logit ("Install Java...", "Java install completed with ErrorCode: " + $installjava)
   
#Create and set %JAVA_HOME%
	Logit ("Configure %JAVA_HOME%...", "Current Setting is:  " + $env:JAVA_HOME)
	Logit ("Configure %JAVA_HOME%...", "Updating to current installed JAVA")
    $osBit = (Get-WmiObject Win32_OperatingSystem).OSArchitecture
    If ($OsBit -eq "64-bit"){
    [Environment]::SetEnvironmentVariable("JAVA_HOME", "C:\Program Files (x86)\Java\jre1.8.0_102" ,"Machine")
    }
    Else{
    [Environment]::SetEnvironmentVariable("JAVA_HOME", "C:\Program Files\Java\jre1.8.0_102" ,"Machine")
    } 
   	Logit ("Completed")




